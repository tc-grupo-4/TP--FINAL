
from numpy import pi

# Configuraciones generales

debug = 0 # Nos dice si mostramos o no los print del programa
max_n = 20

v_ruido = 0.01
v_sat = 15

min_freq = 13.75 *1e3 * 2 * pi #6*1e4 * 2 * pi
max_freq = 1e6
